<template>
  <div
    class="whiteblock"
    :style="'padding: 10px;min-height:' + minHeight + 'px;'"
  >
    <h2 class="red-border-head">{{ Title }}</h2>
    <el-carousel trigger="click" indicator-position="outside" height="280px">
      <el-carousel-item v-for="(item, i) in NewAlbum" :key="'NewAlbum' + i">
        <el-row :gutter="12" style="margin:0 40px">
          <el-col :span="6">
            <el-tooltip
              effect="dark"
              :content="item['item1']['albumTitle']"
              placement="right-start"
            >
              <a :href="item['item1']['albumLink']" target="_blank">
                <el-card shadow="hover" :body-style="{ padding: '0px' }">
                  <img :src="item['item1']['albumImg']" class="image" />
                  <div style="padding: 14px;text-align:left">
                    <p class="album-name">
                      {{ item["item1"]["albumTitle"] }}
                    </p>
                    <el-link
                      :underline="false"
                      type="primary"
                      target="_blank"
                      :href="item['item1']['albumSingerLink']"
                    >
                      <p class="singer">{{ item["item1"]["albumSinger"] }}</p>
                    </el-link>
                    <br />
                    <i class="el-icon-thirdicon-test5 date">{{
                      " " + item["item1"]["albumDate"]
                    }}</i>
                  </div>
                </el-card>
              </a>
            </el-tooltip>
          </el-col>
          <el-col :span="6">
            <el-tooltip
              effect="dark"
              :content="item['item2']['albumTitle']"
              placement="right-start"
            >
              <a :href="item['item2']['albumLink']" target="_blank">
                <el-card shadow="hover" :body-style="{ padding: '0px' }">
                  <img :src="item['item2']['albumImg']" class="image" />
                  <div style="padding: 14px;text-align:left">
                    <p class="album-name">
                      {{ item["item2"]["albumTitle"] }}
                    </p>
                    <el-link
                      :underline="false"
                      type="primary"
                      target="_blank"
                      :href="item['item2']['albumSingerLink']"
                    >
                      <p class="singer">{{ item["item2"]["albumSinger"] }}</p>
                    </el-link>
                    <br />
                    <i class="el-icon-thirdicon-test5 date">{{
                      " " + item["item2"]["albumDate"]
                    }}</i>
                  </div>
                </el-card>
              </a>
            </el-tooltip>
          </el-col>
          <el-col :span="6">
            <el-tooltip
              effect="dark"
              :content="item['item3']['albumTitle']"
              placement="right-start"
            >
              <a :href="item['item3']['albumLink']" target="_blank">
                <el-card shadow="hover" :body-style="{ padding: '0px' }">
                  <img :src="item['item3']['albumImg']" class="image" />
                  <div style="padding: 14px;text-align:left">
                    <p class="album-name">
                      {{ item["item3"]["albumTitle"] }}
                    </p>
                    <el-link
                      :underline="false"
                      type="primary"
                      target="_blank"
                      :href="item['item3']['albumSingerLink']"
                    >
                      <p class="singer">{{ item["item3"]["albumSinger"] }}</p>
                    </el-link>
                    <br />
                    <i class="el-icon-thirdicon-test5 date">{{
                      " " + item["item3"]["albumDate"]
                    }}</i>
                  </div>
                </el-card>
              </a>
            </el-tooltip>
          </el-col>
          <el-col :span="6">
            <el-tooltip
              effect="dark"
              :content="item['item4']['albumTitle']"
              placement="right-start"
            >
              <a :href="item['item4']['albumLink']" target="_blank">
                <el-card shadow="hover" :body-style="{ padding: '0px' }">
                  <img :src="item['item4']['albumImg']" class="image" />
                  <div style="padding: 14px;text-align:left">
                    <p class="album-name">
                      {{ item["item4"]["albumTitle"] }}
                    </p>
                    <el-link
                      :underline="false"
                      type="primary"
                      target="_blank"
                      :href="item['item4']['albumSingerLink']"
                    >
                      <p class="singer">{{ item["item4"]["albumSinger"] }}</p>
                    </el-link>
                    <br />
                    <i class="el-icon-thirdicon-test5 date">{{
                      " " + item["item4"]["albumDate"]
                    }}</i>
                  </div>
                </el-card>
              </a>
            </el-tooltip>
          </el-col>
        </el-row>
      </el-carousel-item>
    </el-carousel>
  </div>
</template>
<script>
export default {
  props: ["NewAlbum", "Title"]
};
</script>
<style lang="scss" scoped>
.album-name {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  vertical-align: middle;
  margin: 5px 0;
}
.singer {
  font-size: 90%;
  color: rgba(0, 0, 0, 0.6);
}

.date {
  font-size: 90%;
  color: rgba(0, 0, 0, 0.6);
}
.el-carousel__item {
  // background: rgba($color: #000000, $alpha: 0.5);
}

.image {
  width: 100%;
  display: block;
}

.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}

.clearfix:after {
  clear: both;
}
</style>
